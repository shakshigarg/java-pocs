const { john } = require('./MyClass');

console.log(john.getName()); // Output: John
