class MyClass {
    constructor(name) {
        this.name = name;
    }

    getName() {
        return this.name;
    }
}

const john = new MyClass("John");
const jane = new MyClass("Jane");

module.exports = { john, jane };
